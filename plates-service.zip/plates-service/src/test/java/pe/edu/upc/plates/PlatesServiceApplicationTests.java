package pe.edu.upc.plates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PlatesServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
