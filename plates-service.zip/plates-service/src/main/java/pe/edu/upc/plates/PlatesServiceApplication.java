package pe.edu.upc.plates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlatesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlatesServiceApplication.class, args);
	}

}
